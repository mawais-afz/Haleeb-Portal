export const environment = {
  production: true,
  ip: 'http://cbl.rtdtradetracker.com/'
};

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tposm-deployment-report',
  templateUrl: './tposm-deployment-report.component.html',
  styleUrls: ['./tposm-deployment-report.component.scss']
})
export class TposmDeploymentReportComponent implements OnInit {
title="Tposm deployment report";
  constructor() { }

  ngOnInit() {
  }

}
